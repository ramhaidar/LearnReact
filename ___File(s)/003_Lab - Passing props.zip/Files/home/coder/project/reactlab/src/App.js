import Heading from "./Heading";

function App() {
    return (
        <div className="App">
            <Heading firstName="Billy"/>
            <Heading firstName="Randall"/>
        </div>
    );
};

export default App;
