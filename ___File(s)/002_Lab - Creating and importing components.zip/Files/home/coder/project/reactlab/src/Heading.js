function Heading() {
  return (
    <h1>Hello World</h1>
  )
}

export default { Heading };