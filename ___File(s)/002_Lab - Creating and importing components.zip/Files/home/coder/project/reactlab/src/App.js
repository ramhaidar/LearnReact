import Heading from "./Heading.js";

function App() {
  return (
    <div className="App">
      This is the starting code for "Your first component" ungraded lab
      <Heading.Heading />
    </div>
  );
}

export default App;
