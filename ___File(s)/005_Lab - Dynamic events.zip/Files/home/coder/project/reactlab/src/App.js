import Button from "./Button"

function App() {
  return (
    <div>
      <h1>Task: Add a button and handle a click event</h1>
      <Button></Button>
    </div>
  );
}

export default App;
